LOA ROGUE SD 영웅 PNG 10명 (2026-11-15)

압축을 푼 뒤 index.html을 브라우저로 열면 한 번에 확인할 수 있습니다.
PNG는 사용자 제공 참고 이미지를 기반으로 새로 생성한 SD 파생 아트입니다. 참고 원본 사진은 포함하지 않습니다.

echidna.png: 에키드나
akkan.png: 일리아칸
kharmine.png: 카마인
kamen.png: 카멘
kakul_saydon.png: 쿠크세이튼
kadan.png: 카단
galatur.png: 갈라투르
delain_arman.png: 데런 아만
luterra.png: 루테란
valtan.png: 발탄

게임에는 무손실 WebP 변환본을 연결합니다. 비아키스·시엔·아만·아브렐슈드의 SD 아트는 아직 준비 중입니다.
